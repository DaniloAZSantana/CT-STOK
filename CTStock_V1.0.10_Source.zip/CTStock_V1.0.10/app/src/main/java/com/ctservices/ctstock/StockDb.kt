package com.ctservices.ctstock

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class StoredComponent(val id:Long,val code:String,val description:String,val qty:Int,val minQty:Int,val column:Int,val drawer:Int)
data class DashboardStats(val totalUnits:Int,val lowStock:Int,val movementsToday:Int)
data class StoredMovement(val id:Long,val code:String,val type:String,val amount:Int,val beforeQty:Int,val afterQty:Int,val createdAt:Long,val column:Int=0,val drawer:Int=0)

class StockDb(context: Context): SQLiteOpenHelper(context,"ctstock.db",null,1){
 override fun onCreate(db:SQLiteDatabase){
  db.execSQL("CREATE TABLE components(id INTEGER PRIMARY KEY AUTOINCREMENT,code TEXT UNIQUE NOT NULL,description TEXT NOT NULL,qty INTEGER NOT NULL,min_qty INTEGER NOT NULL,column_no INTEGER NOT NULL,drawer_no INTEGER NOT NULL)")
  db.execSQL("CREATE TABLE movements(id INTEGER PRIMARY KEY AUTOINCREMENT,code TEXT NOT NULL,type TEXT NOT NULL,amount INTEGER NOT NULL,before_qty INTEGER NOT NULL,after_qty INTEGER NOT NULL,created_at INTEGER NOT NULL)")
  seed(db)
 }
 override fun onUpgrade(db:SQLiteDatabase,oldVersion:Int,newVersion:Int){}
 private fun seed(db:SQLiteDatabase){
  listOf(
   arrayOf("A3120","Optocoupler Driver",8,3,3,12), arrayOf("LM358","Amplificador operacional",14,5,1,5),
   arrayOf("UC3844","PWM Controller",4,3,2,9), arrayOf("RGP02-16E","Diodo rápido",2,4,4,7)
  ).forEach{r-> val v=ContentValues().apply{put("code",r[0] as String);put("description",r[1] as String);put("qty",r[2] as Int);put("min_qty",r[3] as Int);put("column_no",r[4] as Int);put("drawer_no",r[5] as Int)};db.insert("components",null,v)}
 }
 fun components():List<StoredComponent>{val out=mutableListOf<StoredComponent>();readableDatabase.rawQuery("SELECT id,code,description,qty,min_qty,column_no,drawer_no FROM components ORDER BY code",null).use{c->while(c.moveToNext())out+=StoredComponent(c.getLong(0),c.getString(1),c.getString(2),c.getInt(3),c.getInt(4),c.getInt(5),c.getInt(6))};return out}
 fun dashboardStats():DashboardStats{
  val total=readableDatabase.rawQuery("SELECT COALESCE(SUM(qty),0) FROM components",null).use{it.moveToFirst();it.getInt(0)}
  val low=readableDatabase.rawQuery("SELECT COUNT(*) FROM components WHERE qty<=min_qty",null).use{it.moveToFirst();it.getInt(0)}
  val cal=java.util.Calendar.getInstance().apply{set(java.util.Calendar.HOUR_OF_DAY,0);set(java.util.Calendar.MINUTE,0);set(java.util.Calendar.SECOND,0);set(java.util.Calendar.MILLISECOND,0)}
  val today=readableDatabase.rawQuery("SELECT COUNT(*) FROM movements WHERE created_at>=?",arrayOf(cal.timeInMillis.toString())).use{it.moveToFirst();it.getInt(0)}
  return DashboardStats(total,low,today)
 }
 fun monthlySummary(year:Int,month:Int):Pair<Int,Int>{
  val cal=java.util.Calendar.getInstance().apply{set(year,month-1,1,0,0,0);set(java.util.Calendar.MILLISECOND,0)}; val start=cal.timeInMillis;cal.add(java.util.Calendar.MONTH,1);val end=cal.timeInMillis
  var ins=0;var outs=0;readableDatabase.rawQuery("SELECT type,COALESCE(SUM(amount),0) FROM movements WHERE created_at>=? AND created_at<? GROUP BY type",arrayOf(start.toString(),end.toString())).use{c->while(c.moveToNext()){if(c.getString(0)=="retirar")outs=c.getInt(1) else ins=c.getInt(1)}};return ins to outs
 }
 fun movements():List<StoredMovement>{val out=mutableListOf<StoredMovement>();readableDatabase.rawQuery("SELECT m.id,m.code,m.type,m.amount,m.before_qty,m.after_qty,m.created_at,COALESCE(c.column_no,0),COALESCE(c.drawer_no,0) FROM movements m LEFT JOIN components c ON c.code=m.code ORDER BY m.created_at DESC",null).use{c->while(c.moveToNext())out+=StoredMovement(c.getLong(0),c.getString(1),c.getString(2),c.getInt(3),c.getInt(4),c.getInt(5),c.getLong(6),c.getInt(7),c.getInt(8))};return out}
 fun save(item:StoredComponent):Long{
  val code=item.code.trim().uppercase(); val description=item.description.trim()
  require(code.isNotBlank() && description.isNotBlank()) { "Código e descrição são obrigatórios." }
  require(item.qty>=0 && item.minQty>=0) { "Quantidades não podem ser negativas." }
  require(item.column in 1..4 && item.drawer>0) { "Localização inválida." }
  val args=if(item.id==0L) arrayOf(item.column.toString(),item.drawer.toString()) else arrayOf(item.column.toString(),item.drawer.toString(),item.id.toString())
  val sql=if(item.id==0L) "SELECT COUNT(*) FROM components WHERE column_no=? AND drawer_no=?" else "SELECT COUNT(*) FROM components WHERE column_no=? AND drawer_no=? AND id<>?"
  val occupied=readableDatabase.rawQuery(sql,args).use{it.moveToFirst();it.getInt(0)>0}
  require(!occupied) { "Essa gaveta já está ocupada." }
  val v=ContentValues().apply{put("code",code);put("description",description);put("qty",item.qty);put("min_qty",item.minQty);put("column_no",item.column);put("drawer_no",item.drawer)}
  return if(item.id==0L) writableDatabase.insertOrThrow("components",null,v) else {writableDatabase.update("components",v,"id=?",arrayOf(item.id.toString()));item.id}
 }
 fun lowStock():List<StoredComponent> = components().filter { it.qty <= it.minQty }
 fun move(id:Long,type:String,amount:Int):Boolean{val db=writableDatabase;db.beginTransaction();try{val c=db.rawQuery("SELECT code,qty FROM components WHERE id=?",arrayOf(id.toString()));c.use{if(!it.moveToFirst())return false;val code=it.getString(0);val before=it.getInt(1);if(amount<=0 || (type=="retirar" && amount>before)) return false;val after=if(type=="retirar") before-amount else before+amount;val cv=ContentValues().apply{put("qty",after)};db.update("components",cv,"id=?",arrayOf(id.toString()));val mv=ContentValues().apply{put("code",code);put("type",type);put("amount",if(type=="retirar")amount.coerceAtMost(before) else amount);put("before_qty",before);put("after_qty",after);put("created_at",System.currentTimeMillis())};db.insert("movements",null,mv)};db.setTransactionSuccessful()}finally{db.endTransaction()};return true}

 fun clearAndRestore(components:List<StoredComponent>, movements:List<StoredMovement>){
  require(components.all{it.code.isNotBlank()&&it.description.isNotBlank()&&it.qty>=0&&it.minQty>=0&&it.column in 1..4&&it.drawer>0}) { "Backup contém componente inválido." }
  require(components.map{it.code.trim().uppercase()}.distinct().size==components.size) { "Backup contém códigos duplicados." }
  require(components.map{it.column to it.drawer}.distinct().size==components.size) { "Backup contém gavetas duplicadas." }
  require(movements.all{it.code.isNotBlank()&&it.amount>0&&it.beforeQty>=0&&it.afterQty>=0&&it.type in setOf("retirar","guardar")}) { "Backup contém movimentação inválida." }
  val db=writableDatabase;db.beginTransaction();try{
   db.delete("movements",null,null);db.delete("components",null,null)
   components.forEach{x->val v=ContentValues().apply{put("code",x.code.trim().uppercase());put("description",x.description.trim());put("qty",x.qty);put("min_qty",x.minQty);put("column_no",x.column);put("drawer_no",x.drawer)};db.insertOrThrow("components",null,v)}
   movements.sortedBy{it.createdAt}.forEach{m->val v=ContentValues().apply{put("code",m.code.trim().uppercase());put("type",m.type);put("amount",m.amount);put("before_qty",m.beforeQty);put("after_qty",m.afterQty);put("created_at",m.createdAt)};db.insertOrThrow("movements",null,v)}
   db.setTransactionSuccessful()
  }finally{db.endTransaction()}
 }
}
