# CT Stock - regras locais. Mantido intencionalmente enxuto.
