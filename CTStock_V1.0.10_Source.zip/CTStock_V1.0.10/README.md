# CT Stock V1.0.10 — RC2

Revisão de robustez baseada na V1.0.9.

## Correções e validações
- Bloqueio de código duplicado pelo banco.
- Bloqueio de duas peças na mesma Coluna/Gaveta.
- Colunas limitadas a 1–4 e gaveta maior que zero.
- Quantidades e estoque mínimo não podem ser negativos.
- Mensagem de erro de cadastro/edição agora aparece na tela em vez de ser ignorada.
- Retirada só avança para confirmação quando a transação realmente é concluída.
- Restauração de backup valida códigos, gavetas, quantidades e movimentações antes de apagar o estoque atual.
- Restauração é transacional: backup inválido não substitui o banco atual.
- versionCode 10 / versionName 1.0.10.

## Mantido
Busca, voz, scanner, banco SQLite offline, animação da gaveta verde, histórico, estoque baixo, dashboard, CSV mensal e backup JSON.

## Observação de build
Este pacote é o projeto-fonte RC2. O runtime desta conversa não possui Android SDK/Gradle Wrapper configurado, então o APK ainda precisa ser compilado em ambiente Android.
